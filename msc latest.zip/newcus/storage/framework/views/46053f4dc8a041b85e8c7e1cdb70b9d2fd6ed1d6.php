8<center><img width="800" height="500" src="images/500.png"><br>
<h1>Please, select a BOL File</h1></center><?php /**PATH C:\Users\NAVY\Desktop\newcus\resources\views/errorss.blade.php ENDPATH**/ ?>